from django.urls import path
from foods import views


urlpatterns = [
    path('add_food',views.add_food,name='add-food'),
    path('show',views.show_foods,name='show-foods'),
    path('show_food_detail/<int:ap>',views.show_one_food,name='food-detail'),
    path('update_food/<int:ap>',views.update_food,name='update-food'),
    path('delete_food/<int:ap>',views.delete_food,name='delete-food')
]