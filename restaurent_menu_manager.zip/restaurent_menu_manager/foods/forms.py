from django import forms
from .models import Food


class FoodForm(forms.ModelForm):
    class Meta:
        model = Food
        fields = "__all__"

        widgets = {
            'image':forms.FileInput(attrs={'class':'form-control bg-secondary m-1'}),
            'name':forms.TextInput(attrs={'class':'form-control m-2'}),
            'price':forms.NumberInput(attrs={'class':'m-1'}),
            'category':forms.RadioSelect(attrs={'class':'m-1'}),
            'is_prepared':forms.CheckboxInput(attrs={'class':'m-1'}),
            'description':forms.TextInput(attrs={'class':'form-control m-1'})

        }