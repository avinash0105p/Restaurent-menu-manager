from django.contrib import admin

# Register your models here.
from .models import Food

@admin.register(Food)
class FoodAdmin(admin.ModelAdmin):
    list_display = [f.name for f in Food._meta.fields]
