from django.db import models

# Create your models here.
category_choices = [
    ('Veg','Veg'),
    ('Non-Veg','Non-Veg'),
    ('Desserts','Desserts'),
    ('Drinks','Drinks'),
    ('Beverages','Beverages'),
    ('Fast Food','Fast Food'),
    ('Tiffins','Tiffins')

]

class Food(models.Model):
    image = models.ImageField(upload_to='Images/')
    name = models.CharField(max_length=50)
    price = models.FloatField()
    category = models.CharField(max_length=30,choices = category_choices,blank=False,null=False,default='Veg')
    is_prepared = models.BooleanField(default=True)
    description = models.TextField()


    def __str__(self):
        return self.name