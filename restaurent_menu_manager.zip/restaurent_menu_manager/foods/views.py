from django.shortcuts import render,redirect

# Create your views here.
from .forms import FoodForm

from .models import Food

from django.http import HttpResponse

from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage

def show_foods(request):
    foods=Food.objects.all()

    query = request.GET.get('q')

    if(query):
        foods = Food.objects.filter(
            name__icontains = query
        ) or Food.objects.filter(
            category__icontains=query
        )
    else:
         foods=Food.objects.all()




    page_num = request.GET.get('page')
    paginator = Paginator(foods,10)

    try:
        foods = paginator.page(page_num)
    except PageNotAnInteger:
        foods = paginator.page(1)
    except EmptyPage:
        foods = paginator.page(paginator.num_pages)



    context = {
        'all_foods':foods 
    }

    return render(request,'showFoods.html',context) 



def show_one_food(request,ap):
    try:
        one_food = Food.objects.get(id=ap)

        context = {
            'one_food':one_food
        }
        return render(request,'showFoodDetail.html',context)
    except:
        return HttpResponse('<h2>Food Item Not Found</h2>')


def add_food(request):
    form = FoodForm()

    if(request.method == 'POST'):
        form = FoodForm(request.POST,request.FILES)

        if(form.is_valid()):
            form.save()
            return redirect('show-foods')

    context = {
        'form':form
    
    }

    return render(request,'addFood.html',context)


def update_food(request,ap):
    try:
        one_food = Food.objects.get(id=ap)

        form = FoodForm(instance=one_food)

        if(request.method=='POST'):
            form = FoodForm(request.POST,request.FILES,instance=one_food)

            if(form.is_valid()):
                form.save()
                return redirect('show-foods')
            
        context = {
          'form':form
        }

        return render(request,'updateFood.html',context)
        
    except:
        return HttpResponse('<h3>Food Item Not Found...... </h3>')
    


def delete_food(request,ap):
    try:
        one_food = Food.objects.get(id=ap)
        one_food.delete()


        return redirect('show-foods')
    except:
        return HttpResponse('<h3>Food Item Not Found...... </h3>')