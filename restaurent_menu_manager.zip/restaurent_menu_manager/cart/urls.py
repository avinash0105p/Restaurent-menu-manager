from django.urls import path

from cart import views

urlpatterns = [
    path('viewcart',views.view_cart,name='view-cart'),
    path('add2cart/<int:ap>',views.add_2_cart,name='add-2-cart'),
    path('reducequantity/<int:cart_id>',views.reduce_cart_quantity,name='reduce-cart-item'),
    path('removecartitem/<int:cart_id>',views.remove_cart_item,name='remove-cart-item')
]