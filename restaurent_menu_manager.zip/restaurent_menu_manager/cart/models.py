from django.db import models

from foods.models import Food
# Create your models here.


class Cart(models.Model):
    food = models.ForeignKey(Food,on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def total_price(self):
        return self.food.price * self.quantity

